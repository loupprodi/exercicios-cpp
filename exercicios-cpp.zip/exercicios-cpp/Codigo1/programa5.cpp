// Simple C++ program to display "Hello World" 
// Header file for input output functions 
#include<iostream>  
#include<iomanip>
  
using namespace std; 
  
// main function - 
// where the execution of program begins 
int main() 
{ 
    int i=5;
	
	{
		int i =150;
		cout<<i<<endl;
	}
	
	cout<<i<<endl;
      
    return 0; 
} 