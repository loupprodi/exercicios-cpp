// Simple C++ program to display "Hello World" 
// Header file for input output functions 
#include<iostream>  
#include<iomanip>
  
using namespace std; 

// main function - 
// where the execution of program begins 
int main() 
{ 
	char *caractere;
	caractere = new char;
	*caractere = 'M';
	cout<<*caractere;
	
    return 0; 
} 