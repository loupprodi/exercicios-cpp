#include <iostream>
using namespace std;

class Conta{
  private:
   double saldo;

  public:
    Conta(double valorInicial){
        if(valorInicial<0){
          this->saldo = 0;
          cout<<"O Saldo deve ser maior ou igual a 0"<<endl;
        }else{
          this->saldo +=valorInicial;
        }
      } //final do escopo constructor

      double getSaldo(){
        return this->saldo;
      }

      void credito(double valor){
        this->saldo+=valor;
      }

      void debito(double valor){
        if(valor>this->saldo){
          cout<<"Valor maior que o Saldo!"<<endl;
          cout<<"O valor em conta eh: "<<this->saldo<<endl;
        }else{
          this->saldo-=valor;
        }
      }
};

int main() { 

  Conta joao = Conta(1000);

  cout<<"O saldo da conta éh"<<joao.getSaldo()<<endl;
  joao.credito(1000);
  cout<<"O saldo da conta éh"<<joao.getSaldo()<<endl;
  joao.debito(2500);
     return 0;
}