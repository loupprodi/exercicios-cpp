#include <iostream>
#include <string>

using namespace std;

class NotaFiscal{
  private:
   string numPeca;
   string descPeca;
   int quantPeca;
   double preco;

  public:
   
    //constructor vazio
    //NotaFiscal();

    //constructor se o usuario querer inicializar a instancia
    NotaFiscal(string numPeca, string descPeca, int quantPeca, double preco){
     this->numPeca = numPeca;
     this->descPeca = descPeca ;
     this->quantPeca = quantPeca;
     this->preco = preco;
	}
  

	void setnumPeca(string numPeca){
        this->numPeca = numPeca;
	}

	void setdescPeca(string descPeca){
        this->descPeca = descPeca;
	}
	
	void setquantPeca(int quantPeca){
        this->quantPeca = quantPeca;
	}
		
	void setpreco(int preco){
        this->preco = preco;
	}
	
	string getnumPeca ()
		{
			return numPeca;
		}
	
	string getdescPeca ()
		{
			return descPeca;
		}
		
	int getquantPeca ()
		{
			return quantPeca;
		}
	
	double getpreco ()
		{
			return preco;
		}
		
	double getTotalNota()
		{
			double Total;
			return Total = this-> quantPeca * this-> preco;
		}
	
};

int main() { 
	 
	 NotaFiscal nota1 = NotaFiscal("1", "chave de fenda", 50, 5.50);

     NotaFiscal nota2 = NotaFiscal("2", "alicate", 20, 12.50);

	 NotaFiscal nota3 = NotaFiscal("3", "chave philips", 10, 20.40);
	 
	
	 cout<<"O total da nota eh: "<<nota1.getTotalNota()<<endl;
	 cout<<"O total da nota eh: "<<nota2.getTotalNota()<<endl;
	 cout<<"O total da nota eh: "<<nota3.getTotalNota()<<endl;
	 
	 
     return 0;
}