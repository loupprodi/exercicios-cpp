#include <iostream>
#include <string>

using namespace std;

class Empregado{
  private:
  string nome;
  string sobreNome;
  double salarioMensal;   

  public:
  
  //Constructor
  
  Empregado();
  
  Empregado (string nome){
	  this-> nome = nome;
  }
  
  Empregado (string sobreNome){
	  this-> sobreNome = sobreNome;
  }
  
  Empregado (double salarioMensal){
	  this-> salarioMensal = salarioMensal;
  }
  
  //Setters
  
	void setnome(string nome){
        this->nome = nome;
	}
	
	void setsobreNome(string sobreNome){
        this->sobreNome = sobreNome;
	}
	
	void setsalarioMensal(string salarioMensal){
        this->salarioMensal = salarioMensal;
	}
	
	//Getter
	
	string getnome ()
		{
			return this -> nome;
		}
		
	string getsobreNome ()
		{
			return this -> sobreNome;
		}
		
	double getsalarioMensal ()
		{
			return this -> salarioMensal;
		}


int main() { 
	
	string nome, sobreNome;
	double salarioMensal;
	
	cout << "Digite o nome do empregado: "<<endl;
	getline(cin, nome);
	
	cout << "Digite o sobrenome do empregado: "<<endl;
	getline(cin, sobreNome);
	
	cout << "Digite o salario mensal do empregado: "<<endl;
	getline(cin, salarioMensal);
	
	Empregado empregado1 = Empregado(nome);
	empregado1.setsobreNome(sobreNome);
	empregado1.setsalarioMensal(salarioMensal);
	
	aumento = empregado.getsalarioMensal()120.10;
	salarioAnual = (empregado1.getsalarioMensal() * 12) + aumento;
	
	cout<<"Empregado: "<<empregado1.getnome()<<" Sobrenome "<<empregado1.getsobreNomeome()<<endl;
	cout<<"Salario: "<<empregado1.getsalarioMensal()<<<" Ganha anualmente: "<<salarioAnual<<endl;
	
	
     return 0;
}

